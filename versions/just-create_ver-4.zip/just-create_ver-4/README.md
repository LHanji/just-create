# just-create

EM ANDAMENTO...

Este é um projeto de um site em que, tendo criado uma conta e feito login, o usuário poderá adicionar a uma biblioteca suas criações, seus personagens. Com isso você pode deixar guardado o que vem na mente naqueles momentos de explosão criativa, guardar suas criações.

Na criação será possível adicionar atributos como nome, classe, reino, história, etc, além de permitir que seja vinculado ao personagem um desenho feito pelo usuário.

Desenvolvido como CRUD para as aulas de Desenvolvimento para Internet do Prof. Renato por Lohana Torres e Lucas Hote.
