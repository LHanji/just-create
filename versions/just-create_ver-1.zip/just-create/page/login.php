<?php
echo "funcionou";
?>