<?php
    echo "logado";
?>