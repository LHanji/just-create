<?php
    session_start();
    $username=$_SESSION["username"];
    if(!$username)
    {
        $_SESSION["error"] = "Você precisa faze login para acessar esta página.";
        header("location:login.php");
        die();
    } else{
        include 'just_create_profile.php';
        include 'char_library';
    }
?>