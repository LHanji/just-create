<?php

    include '../script/go_session.php';

    function title(){
        echo 'Fazer login';
    }

    function heading(){
        echo '<h1>Login</h1>';
    }

    function page(){
        echo '../script/server.php';
    }

    //include 'errors.php';

    function form_content(){
        echo '
            <div class="form-group">
                <label for="username">Usuário: </label>
                <input type="text" name="username" id="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Senha: </label>
                <input type="password" name="pwd" id="pwd" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary" name="logBtn">Cadastrar-se</button>
            <br><br>
            <p>Não possui conta?<a href="register.php"> Cadastre-se</a></p>';
    }    
    include '../template/template_form.php';
?>