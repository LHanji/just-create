<?php
    echo '<?php session_start();
        $error = $_SESSION["error"]?>';
?>
